import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'plant-diseases-classification';
  imagePath:any
  
  // result:{class:string,confidence:number} ;
  result:any;
  constructor(private http :HttpClient){
this.result=null
  

  }

  fileToUpload:any;

  handleFileInput(event:any) {
    if(event!==null){
      this.fileToUpload = event.target.files.item(0);
     
    }
    
}
  upload(){

    var fd = new FormData();
    fd.append("file",this.fileToUpload);
  //  fd.append('file', this.fileToUpload,this.fileToUpload?.name);
    this.http.post(`http://localhost:8500/predict`,fd).subscribe((res)=>{
      var reader = new FileReader();
     
      reader.readAsDataURL(this.fileToUpload); 
      reader.onload = (_event) => { 
        this.imagePath = reader.result; 
      }
    
    this.result=res;
    })
  }
}
